// Hier den Code ergaenzen 
// (Event-Handling fuer Hinzufuegen-Button, DOM-Manipulation fuer Tabelle)

function createCheckbox(tr) {
  // Hier den Code fuer die Erzeugung der Checkbox ergaenzen
  // Empfohlene Strategie:
  // 1. Erstelle eine Checkbox per DOM-API
  // 2. Fuege einen Event-Handler fuer Klick auf die Checkbox hinzu
  // 3. Falls Checkbox angehakt (checked): Text in Zeile (tr) durchstreichen
  // 4. Sonst: Text in Zeile (tr) normal darstellen
}
