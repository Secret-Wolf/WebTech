const bilder = [
  {
    dateiname: "robot.png",
    beschreibung: "Frida Kahlo painting of a robot waving goodbye",
  },
  {
    dateiname: "meadow.png",
    beschreibung:
      "A photo of a wide green meadow and a clear blue sky",
  },
  {
    dateiname: "elephant.png",
    beschreibung: "A pink elephant in a small room",
  },
  {
    dateiname: "fhdortmund.png",
    beschreibung: "An expressive oil painting of FH Dortmund in summer",
  },
];

// Hier den Code ergaenzen!
